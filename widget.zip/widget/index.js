window.onload = () => {
  const app = document.createElement('ion-app');
  document.body.appendChild(app);
};